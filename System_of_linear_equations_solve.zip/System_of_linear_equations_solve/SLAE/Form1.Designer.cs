﻿namespace SLAE
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewMatrix = new System.Windows.Forms.DataGridView();
            this.dataGridViewVector = new System.Windows.Forms.DataGridView();
            this.dataGridViewResult = new System.Windows.Forms.DataGridView();
            this.buttonMinusSize = new System.Windows.Forms.Button();
            this.labelSizeSLAE = new System.Windows.Forms.Label();
            this.labelA = new System.Windows.Forms.Label();
            this.labelVectorB = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonGenerator = new System.Windows.Forms.Button();
            this.checkBoxEquality = new System.Windows.Forms.CheckBox();
            this.labelTimeLU = new System.Windows.Forms.Label();
            this.buttonClear = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.buttonPlusSize = new System.Windows.Forms.Button();
            this.buttonLU = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.GraphPanel = new System.Windows.Forms.Panel();
            this.openGLControl1 = new SharpGL.OpenGLControl();
            this.RedTextBox = new System.Windows.Forms.TextBox();
            this.GreenTextBox = new System.Windows.Forms.TextBox();
            this.BlueTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMatrix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVector)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResult)).BeginInit();
            this.GraphPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewMatrix
            // 
            this.dataGridViewMatrix.AllowUserToAddRows = false;
            this.dataGridViewMatrix.AllowUserToResizeColumns = false;
            this.dataGridViewMatrix.AllowUserToResizeRows = false;
            this.dataGridViewMatrix.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewMatrix.BackgroundColor = System.Drawing.SystemColors.MenuBar;
            this.dataGridViewMatrix.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMatrix.ColumnHeadersVisible = false;
            this.dataGridViewMatrix.Location = new System.Drawing.Point(15, 32);
            this.dataGridViewMatrix.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewMatrix.Name = "dataGridViewMatrix";
            this.dataGridViewMatrix.RowHeadersVisible = false;
            this.dataGridViewMatrix.RowHeadersWidth = 40;
            this.dataGridViewMatrix.RowTemplate.Height = 24;
            this.dataGridViewMatrix.Size = new System.Drawing.Size(264, 243);
            this.dataGridViewMatrix.TabIndex = 1;
            this.dataGridViewMatrix.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewMatrix_CellContentClick);
            // 
            // dataGridViewVector
            // 
            this.dataGridViewVector.AllowUserToAddRows = false;
            this.dataGridViewVector.AllowUserToResizeColumns = false;
            this.dataGridViewVector.AllowUserToResizeRows = false;
            this.dataGridViewVector.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewVector.BackgroundColor = System.Drawing.SystemColors.MenuBar;
            this.dataGridViewVector.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVector.ColumnHeadersVisible = false;
            this.dataGridViewVector.Location = new System.Drawing.Point(300, 32);
            this.dataGridViewVector.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewVector.Name = "dataGridViewVector";
            this.dataGridViewVector.RowHeadersVisible = false;
            this.dataGridViewVector.RowTemplate.Height = 24;
            this.dataGridViewVector.Size = new System.Drawing.Size(66, 243);
            this.dataGridViewVector.TabIndex = 2;
            // 
            // dataGridViewResult
            // 
            this.dataGridViewResult.AllowUserToResizeColumns = false;
            this.dataGridViewResult.AllowUserToResizeRows = false;
            this.dataGridViewResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewResult.BackgroundColor = System.Drawing.SystemColors.MenuBar;
            this.dataGridViewResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewResult.ColumnHeadersVisible = false;
            this.dataGridViewResult.Location = new System.Drawing.Point(385, 32);
            this.dataGridViewResult.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewResult.Name = "dataGridViewResult";
            this.dataGridViewResult.RowHeadersVisible = false;
            this.dataGridViewResult.RowTemplate.Height = 24;
            this.dataGridViewResult.Size = new System.Drawing.Size(86, 243);
            this.dataGridViewResult.TabIndex = 3;
            this.dataGridViewResult.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewResult_CellContentClick);
            // 
            // buttonMinusSize
            // 
            this.buttonMinusSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonMinusSize.Location = new System.Drawing.Point(915, 352);
            this.buttonMinusSize.Margin = new System.Windows.Forms.Padding(2);
            this.buttonMinusSize.Name = "buttonMinusSize";
            this.buttonMinusSize.Size = new System.Drawing.Size(10, 12);
            this.buttonMinusSize.TabIndex = 4;
            this.buttonMinusSize.Text = "-";
            this.buttonMinusSize.UseVisualStyleBackColor = true;
            this.buttonMinusSize.Click += new System.EventHandler(this.buttonMinusSize_Click);
            // 
            // labelSizeSLAE
            // 
            this.labelSizeSLAE.AutoSize = true;
            this.labelSizeSLAE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.labelSizeSLAE.Location = new System.Drawing.Point(11, 291);
            this.labelSizeSLAE.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSizeSLAE.Name = "labelSizeSLAE";
            this.labelSizeSLAE.Size = new System.Drawing.Size(82, 24);
            this.labelSizeSLAE.TabIndex = 6;
            this.labelSizeSLAE.Text = "Размер:";
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.labelA.Location = new System.Drawing.Point(11, 6);
            this.labelA.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(23, 24);
            this.labelA.TabIndex = 7;
            this.labelA.Text = "A";
            // 
            // labelVectorB
            // 
            this.labelVectorB.AutoSize = true;
            this.labelVectorB.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelVectorB.Location = new System.Drawing.Point(296, 6);
            this.labelVectorB.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelVectorB.Name = "labelVectorB";
            this.labelVectorB.Size = new System.Drawing.Size(21, 24);
            this.labelVectorB.TabIndex = 8;
            this.labelVectorB.Text = "b";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label1.Location = new System.Drawing.Point(381, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "x";
            // 
            // buttonGenerator
            // 
            this.buttonGenerator.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonGenerator.Location = new System.Drawing.Point(262, 291);
            this.buttonGenerator.Margin = new System.Windows.Forms.Padding(2);
            this.buttonGenerator.Name = "buttonGenerator";
            this.buttonGenerator.Size = new System.Drawing.Size(104, 34);
            this.buttonGenerator.TabIndex = 10;
            this.buttonGenerator.Text = "Random";
            this.buttonGenerator.UseVisualStyleBackColor = true;
            this.buttonGenerator.Click += new System.EventHandler(this.buttonGenerator_Click);
            // 
            // checkBoxEquality
            // 
            this.checkBoxEquality.AutoSize = true;
            this.checkBoxEquality.Enabled = false;
            this.checkBoxEquality.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.checkBoxEquality.Location = new System.Drawing.Point(675, 336);
            this.checkBoxEquality.Margin = new System.Windows.Forms.Padding(2);
            this.checkBoxEquality.Name = "checkBoxEquality";
            this.checkBoxEquality.Size = new System.Drawing.Size(225, 28);
            this.checkBoxEquality.TabIndex = 11;
            this.checkBoxEquality.Text = "Совпадение решения";
            this.checkBoxEquality.UseVisualStyleBackColor = true;
            this.checkBoxEquality.CheckedChanged += new System.EventHandler(this.checkBoxEquality_CheckedChanged);
            // 
            // labelTimeLU
            // 
            this.labelTimeLU.AutoSize = true;
            this.labelTimeLU.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.labelTimeLU.Location = new System.Drawing.Point(475, 77);
            this.labelTimeLU.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTimeLU.Name = "labelTimeLU";
            this.labelTimeLU.Size = new System.Drawing.Size(67, 24);
            this.labelTimeLU.TabIndex = 14;
            this.labelTimeLU.Text = "Время";
            this.labelTimeLU.Click += new System.EventHandler(this.labelTimeLU_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonClear.Location = new System.Drawing.Point(454, 291);
            this.buttonClear.Margin = new System.Windows.Forms.Padding(2);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(116, 34);
            this.buttonClear.TabIndex = 18;
            this.buttonClear.Text = "Очистить";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.comboBox1.Location = new System.Drawing.Point(98, 294);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(43, 21);
            this.comboBox1.TabIndex = 19;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // buttonPlusSize
            // 
            this.buttonPlusSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonPlusSize.Location = new System.Drawing.Point(904, 352);
            this.buttonPlusSize.Margin = new System.Windows.Forms.Padding(2);
            this.buttonPlusSize.Name = "buttonPlusSize";
            this.buttonPlusSize.Size = new System.Drawing.Size(10, 12);
            this.buttonPlusSize.TabIndex = 5;
            this.buttonPlusSize.Text = "+";
            this.buttonPlusSize.UseVisualStyleBackColor = true;
            this.buttonPlusSize.Click += new System.EventHandler(this.buttonPlusSize_Click);
            // 
            // buttonLU
            // 
            this.buttonLU.Location = new System.Drawing.Point(476, 32);
            this.buttonLU.Name = "buttonLU";
            this.buttonLU.Size = new System.Drawing.Size(75, 23);
            this.buttonLU.TabIndex = 27;
            this.buttonLU.Text = "Решить";
            this.buttonLU.UseVisualStyleBackColor = true;
            this.buttonLU.Click += new System.EventHandler(this.buttonLU_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(147, 285);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 40);
            this.label2.TabIndex = 29;
            this.label2.Text = "Заполнить матрицу случайными значеинями";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(394, 291);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 34);
            this.label3.TabIndex = 30;
            this.label3.Text = "Очистить матрицу";
            // 
            // GraphPanel
            // 
            this.GraphPanel.Controls.Add(this.openGLControl1);
            this.GraphPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.GraphPanel.Location = new System.Drawing.Point(841, 0);
            this.GraphPanel.Name = "GraphPanel";
            this.GraphPanel.Size = new System.Drawing.Size(375, 461);
            this.GraphPanel.TabIndex = 31;
            // 
            // openGLControl1
            // 
            this.openGLControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.openGLControl1.DrawFPS = false;
            this.openGLControl1.FrameRate = 10;
            this.openGLControl1.Location = new System.Drawing.Point(0, 0);
            this.openGLControl1.Name = "openGLControl1";
            this.openGLControl1.OpenGLVersion = SharpGL.Version.OpenGLVersion.OpenGL2_1;
            this.openGLControl1.RenderContextType = SharpGL.RenderContextType.DIBSection;
            this.openGLControl1.RenderTrigger = SharpGL.RenderTrigger.TimerBased;
            this.openGLControl1.Size = new System.Drawing.Size(375, 461);
            this.openGLControl1.TabIndex = 0;
            this.openGLControl1.OpenGLDraw += new SharpGL.RenderEventHandler(this.openGLControl1_OpenGLDraw);
            // 
            // RedTextBox
            // 
            this.RedTextBox.Location = new System.Drawing.Point(359, 351);
            this.RedTextBox.Name = "RedTextBox";
            this.RedTextBox.Size = new System.Drawing.Size(47, 20);
            this.RedTextBox.TabIndex = 32;
            this.RedTextBox.Text = "255";
            this.RedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GreenTextBox
            // 
            this.GreenTextBox.Location = new System.Drawing.Point(427, 351);
            this.GreenTextBox.Name = "GreenTextBox";
            this.GreenTextBox.Size = new System.Drawing.Size(47, 20);
            this.GreenTextBox.TabIndex = 33;
            this.GreenTextBox.Text = "255";
            this.GreenTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BlueTextBox
            // 
            this.BlueTextBox.Location = new System.Drawing.Point(495, 351);
            this.BlueTextBox.Name = "BlueTextBox";
            this.BlueTextBox.Size = new System.Drawing.Size(47, 20);
            this.BlueTextBox.TabIndex = 34;
            this.BlueTextBox.Text = "255";
            this.BlueTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(251, 349);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 22);
            this.label4.TabIndex = 35;
            this.label4.Text = "Цвет сетки";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 352);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 42);
            this.button1.TabIndex = 36;
            this.button1.Text = "Заполнить из файла";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(15, 400);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(152, 39);
            this.button2.TabIndex = 37;
            this.button2.Text = "Вывести в файл";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1216, 461);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.BlueTextBox);
            this.Controls.Add(this.GreenTextBox);
            this.Controls.Add(this.RedTextBox);
            this.Controls.Add(this.GraphPanel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonLU);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.labelTimeLU);
            this.Controls.Add(this.checkBoxEquality);
            this.Controls.Add(this.buttonGenerator);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelVectorB);
            this.Controls.Add(this.labelA);
            this.Controls.Add(this.labelSizeSLAE);
            this.Controls.Add(this.buttonPlusSize);
            this.Controls.Add(this.buttonMinusSize);
            this.Controls.Add(this.dataGridViewResult);
            this.Controls.Add(this.dataGridViewVector);
            this.Controls.Add(this.dataGridViewMatrix);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "SLAE Calculator";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMatrix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVector)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResult)).EndInit();
            this.GraphPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridViewMatrix;
        private System.Windows.Forms.DataGridView dataGridViewVector;
        private System.Windows.Forms.DataGridView dataGridViewResult;
        private System.Windows.Forms.Button buttonMinusSize;
        private System.Windows.Forms.Label labelSizeSLAE;
        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.Label labelVectorB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonGenerator;
        private System.Windows.Forms.CheckBox checkBoxEquality;
        private System.Windows.Forms.Label labelTimeLU;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button buttonPlusSize;
        private System.Windows.Forms.Button buttonLU;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel GraphPanel;
        private SharpGL.OpenGLControl openGLControl1;
        private System.Windows.Forms.TextBox RedTextBox;
        private System.Windows.Forms.TextBox GreenTextBox;
        private System.Windows.Forms.TextBox BlueTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

