﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using ZedGraph;
using SharpGL;
using System.IO;

namespace SLAE
{
    public partial class Form1 : Form
    {
        int size = 2;
        double[,] matrix;
        double[] b;

        public Form1()
        {
            InitializeComponent();

            labelTimeLU.Text= "Время - ";         
            dataGridViewMatrix.ColumnCount = size;
            dataGridViewMatrix.RowCount = size;
            dataGridViewVector.RowCount = size;
            dataGridViewResult.RowCount = size;

            foreach (DataGridViewColumn column in dataGridViewMatrix.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            foreach (DataGridViewColumn column in dataGridViewVector.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            foreach (DataGridViewColumn column in dataGridViewResult.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            GraphPane pane = new GraphPane();

            InitOpenGL();
        }

        private OpenGL GL => openGLControl1.OpenGL;
        private int RedValue => int.Parse(RedTextBox.Text);
        private int GreenValue => int.Parse(GreenTextBox.Text);
        private int BlueValue => int.Parse(BlueTextBox.Text);

        private void InitOpenGL()
        {
            GL.MatrixMode(SharpGL.Enumerations.MatrixMode.Modelview);

            GL.LoadIdentity();
            GL.LookAt(2.5, 1, 2, 0, 0, 0, 0, 0, 1);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int oldSize = size;
            if (comboBox1.SelectedIndex + 2 < oldSize)
            {
                for (int i = 0; i < oldSize - comboBox1.SelectedIndex - 2; ++i)
                {
                    size--;
                    dataGridViewMatrix.Rows.RemoveAt(size - 1);
                    dataGridViewMatrix.Columns.Remove("");

                    dataGridViewVector.Rows.RemoveAt(size - 1);
                    dataGridViewResult.Rows.RemoveAt(size - 1);
                }      
            }
            else if (comboBox1.SelectedIndex + 2 > oldSize)
            {
                for (int i = 0; i < comboBox1.SelectedIndex - oldSize + 2; ++i)
                {
                    size++;
                    dataGridViewMatrix.Rows.Add();
                    dataGridViewMatrix.Columns.Add("", "");

                    dataGridViewVector.Rows.Add();
                    dataGridViewResult.Rows.Add();
                }
            }
        }

        private void buttonMinusSize_Click(object sender, EventArgs e)
        {
            if (size != 3)
            {
                buttonMinusSize.Enabled = true;

                size--;

                dataGridViewMatrix.Rows.RemoveAt(size - 1);
                dataGridViewMatrix.Columns.Remove("");

                dataGridViewVector.Rows.RemoveAt(size - 1);
                dataGridViewResult.Rows.RemoveAt(size - 1);

                buttonClear_Click(sender, e);

                if (size == 3)
                {
                    buttonMinusSize.Enabled = false;
                }
                if (size < 8)
                {
                    buttonPlusSize.Enabled = true;
                }
            }
        }

        private void buttonPlusSize_Click(object sender, EventArgs e)
        {
            if (size != 8)
            {
                buttonPlusSize.Enabled = true;

                size++;
                dataGridViewMatrix.Rows.Add();
                dataGridViewMatrix.Columns.Add("", "");

                dataGridViewVector.Rows.Add();
                dataGridViewResult.Rows.Add();

                buttonClear_Click(sender, e);

                if (size == 8)
                {
                    buttonPlusSize.Enabled = false;
                }
                if (size > 3)
                {
                    buttonMinusSize.Enabled = true;
                }
            }
        }
       
        private void buttonGenerator_Click(object sender, EventArgs e)
        {
            GeneratorMatrix generator = new GeneratorMatrix();
            matrix = generator.GenerateMatrix(size);
            b = generator.GenerateVector(size);

            for (int i = 0; i < dataGridViewMatrix.ColumnCount; i++)
            {
                for (int j = 0; j < dataGridViewMatrix.ColumnCount; j++)
                {
                    dataGridViewMatrix.Rows[i].Cells[j].Value = matrix[i, j];
                }

                dataGridViewVector.Rows[i].Cells[0].Value = b[i];
            }

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridViewMatrix.ColumnCount; i++)
            {
                for (int j = 0; j < dataGridViewMatrix.ColumnCount; j++)
                {
                    dataGridViewMatrix.Rows[i].Cells[j].Value = "";
                }

                dataGridViewVector.Rows[i].Cells[0].Value = "";
                dataGridViewResult.Rows[i].Cells[0].Value = "";
            }


            labelTimeLU.Text = "Время   - ";           
             
        }

        private void buttonLU_Click(object sender, EventArgs e)
        {
            GeneratorMatrix generator = new GeneratorMatrix();
            matrix = generator.GenerateMatrix(size);
            b = generator.GenerateVector(size);

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    matrix[i, j] = Convert.ToDouble(dataGridViewMatrix.Rows[i].Cells[j].Value);
                }

                b[i] = Convert.ToDouble(dataGridViewVector.Rows[i].Cells[0].Value);
            }

            LUDecomposition luDecomposition = new LUDecomposition();
            Stopwatch time = new Stopwatch();
            time.Start();
            double[] luSolution = luDecomposition.Solve(matrix, b);
            time.Stop();

            for (int i = 0; i < size; i++)
            {
                dataGridViewResult.Rows[i].Cells[0].Value = luSolution[i];
            }

           
            labelTimeLU.Text = "Время - " + time.Elapsed.TotalSeconds; 

        } 

        private void labelTimeRotation_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewMatrix_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void labelTimeLU_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewResult_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void openGLControl1_OpenGLDraw(object sender, RenderEventArgs args)
        {
            // Очистка экрана и буфера глубин
            GL.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

            DrawAxes();
            DrawSurface();
        }

        private void DrawAxes()
        {
            GL.Begin(OpenGL.GL_LINES);

            GL.Color(1f, 0, 0);

            GL.Vertex(-50, 0, 0);
            GL.Vertex(50, 0, 0);

            GL.Color(0, 1f, 0);

            GL.Vertex(0, -50, 0);
            GL.Vertex(0, 50, 0);

            GL.Color(0, 0, 1f);

            GL.Vertex(0, 0, -50);
            GL.Vertex(0, 0, 50);

            GL.End();
        }

        private void DrawSurface()
        {
            double[,] matrix = new double[dataGridViewMatrix.RowCount, dataGridViewMatrix.ColumnCount];
            double min = double.MaxValue;
            double max = double.MinValue;
            for (int i = 0; i < dataGridViewMatrix.RowCount; i++)
            {
                for (int j = 0; j < dataGridViewMatrix.ColumnCount; j++)
                {
                    matrix[i, j] = Convert.ToDouble(dataGridViewMatrix.Rows[i].Cells[j].Value);

                    if (matrix[i, j] > max)
                        max = matrix[i, j];

                    if (matrix[i, j] < min)
                        min = matrix[i, j];
                }
            }

            for (int i = 0; i < dataGridViewMatrix.RowCount; i++)
            {
                for (int j = 0; j < dataGridViewMatrix.ColumnCount; j++)
                {
                    matrix[i, j] -= min;
                    matrix[i, j] /= (max - min);
                }
            }


            GL.Begin(OpenGL.GL_LINES);

            GL.Color(RedValue / 255f, GreenValue / 255f, BlueValue / 255f);
            
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    double startX = (double)i / (dataGridViewMatrix.RowCount - 1);
                    double startY = (double)j / (dataGridViewMatrix.ColumnCount - 1);

                    double endX = (double)(i + 1) / (dataGridViewMatrix.RowCount - 1);
                    double endY = (double)(j + 1) / (dataGridViewMatrix.ColumnCount - 1);

                    
                    try
                    {
                        double v00 = matrix[i, j];
                        double v10 = matrix[i + 1, j];
                        double v11 = matrix[i + 1, j + 1];
                        double v01 = matrix[i, j + 1];

                        GL.Vertex(startX, startY, v00);
                        GL.Vertex(startX, endY, v10);

                        GL.Vertex(startX, endY, v10);
                        GL.Vertex(endX, endY, v11);

                        GL.Vertex(endX, endY, v11);
                        GL.Vertex(endX, startY, v01);

                        GL.Vertex(endX, startY, v01);
                        GL.Vertex(startX, startY, v00);



                    }
                    catch (IndexOutOfRangeException)
                    {
                    }
                }
            }
            GL.End();

        }

        private void checkBoxEquality_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] str;

            // dataGridViewMatrix.ColumnCount = size;
            // dataGridViewMatrix.RowCount = size; //например вот здесь
            string path = "";
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                path = ofd.FileName;

            }
            FileStream pathh = new FileStream(path, FileMode.Create);
            StreamWriter streamWriter = new StreamWriter(pathh);

            try
            {
                for (int j = 0; j < dataGridViewResult.Rows.Count; j++)
                {
                    for (int i = 0; i < dataGridViewResult.Rows[j].Cells.Count; i++)
                    {
                        streamWriter.Write(dataGridViewResult.Rows[j].Cells[0].Value + "     ");
                    }

                    streamWriter.WriteLine();
                }

                streamWriter.Close();
                pathh.Close();

                MessageBox.Show("Файл успешно сохранен");
            }
            catch
            {
                MessageBox.Show("Ошибка при сохранении файла!");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] str;

           // dataGridViewMatrix.ColumnCount = size;
           // dataGridViewMatrix.RowCount = size; //например вот здесь
            string path = "";
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                path = ofd.FileName;

            }

            using (System.IO.StreamReader read = new System.IO.StreamReader(path))
            {
                str = read.ReadToEnd().Split(new Char[] { ' ', '\r' }); // и n 
                int pos = 0;


                for (int i = 0; i < dataGridViewMatrix.ColumnCount; i++)
                {
                    for (int j = 0; j < dataGridViewMatrix.ColumnCount; j++)
                    {
                        
                        while (str[pos] == "")
                        {
                            pos++;
                        }

                        // dataGridViewMatrix[j, i].Value = str[pos];
                        dataGridViewMatrix.Rows[i].Cells[j].Value = str[pos];
                        //dataGridViewVector.Rows[i].Cells[0].Value = str[pos];

                        pos++;
                    }
                    dataGridViewVector.Rows[i].Cells[0].Value = str[pos];
                    pos++;

                }
            }
        }
    }
}
